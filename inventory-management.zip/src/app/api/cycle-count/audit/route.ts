import { NextResponse } from 'next/server';

export async function GET() {
  try {
    // Mock data - in real implementation, this would fetch from database
    const audits = [
      {
        id: '1',
        timestamp: '2025-01-30 15:30:25',
        user: 'manager@company.com',
        fileName: 'cycle_count_jan_2025.xlsx',
        varianceSKUs: 15,
        totalAdjQtyCS: 45,
        status: 'Completed'
      },
      {
        id: '2',
        timestamp: '2025-01-15 14:20:15',
        user: 'admin@company.com',
        fileName: 'cycle_count_mid_jan.xlsx',
        varianceSKUs: 8,
        totalAdjQtyCS: 23,
        status: 'Completed'
      },
      {
        id: '3',
        timestamp: '2024-12-31 16:45:30',
        user: 'manager@company.com',
        fileName: 'year_end_count.xlsx',
        varianceSKUs: 25,
        totalAdjQtyCS: 67,
        status: 'Completed'
      },
      {
        id: '4',
        timestamp: '2024-12-15 11:30:45',
        user: 'admin@company.com',
        fileName: 'dec_cycle_count.xlsx',
        varianceSKUs: 0,
        totalAdjQtyCS: 0,
        status: 'Failed'
      }
    ];

    return NextResponse.json(audits);
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch audit list' },
      { status: 500 }
    );
  }
} 