import { NextResponse } from 'next/server';

export async function GET() {
  try {
    // Mock data - in real implementation, this would fetch from database
    const runs = [
      {
        timestamp: '2025-01-30 14:30:25',
        user: 'admin@company.com',
        status: 'Success',
        message: ''
      },
      {
        timestamp: '2025-01-29 02:00:15',
        user: 'system',
        status: 'Success',
        message: ''
      },
      {
        timestamp: '2025-01-28 14:45:30',
        user: 'admin@company.com',
        status: 'Error',
        message: 'Database connection timeout'
      },
      {
        timestamp: '2025-01-27 02:00:12',
        user: 'system',
        status: 'Success',
        message: ''
      },
      {
        timestamp: '2025-01-26 15:20:45',
        user: 'manager@company.com',
        status: 'Success',
        message: ''
      },
      {
        timestamp: '2025-01-25 02:00:08',
        user: 'system',
        status: 'Success',
        message: ''
      },
      {
        timestamp: '2025-01-24 16:10:22',
        user: 'admin@company.com',
        status: 'Error',
        message: 'Insufficient memory for large dataset'
      },
      {
        timestamp: '2025-01-23 02:00:05',
        user: 'system',
        status: 'Success',
        message: ''
      },
      {
        timestamp: '2025-01-22 11:35:18',
        user: 'manager@company.com',
        status: 'Success',
        message: ''
      },
      {
        timestamp: '2025-01-21 02:00:02',
        user: 'system',
        status: 'Success',
        message: ''
      }
    ];

    return NextResponse.json(runs);
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch refresh log' },
      { status: 500 }
    );
  }
} 